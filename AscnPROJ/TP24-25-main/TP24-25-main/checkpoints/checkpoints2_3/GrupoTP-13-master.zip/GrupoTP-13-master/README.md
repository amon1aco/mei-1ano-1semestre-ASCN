<img src='uminho.png' width="30%"/>

<h3 align="center">Mestrado em Engenharia Informática <br> Trabalho prático Aplicações e Serviços de Computação em Nuvem <br> 2024/2025 </h3>

---

### Instruções


[Moonshot Repo](https://github.com/ASCN-UM/moonshot.git)

---
<h3 align="center">Equipa</h3>

<div align="center">

| Nome             | Número |
|------------------|--------|
| Augusto Campos   | PG57510|
| Tiago F. Silva   | PG57614|
| Tiago P. Silva   | PG57617|
| Carlos Silva     | PG57518|
| Eduardo Cunha    | PG55939|

</div>



